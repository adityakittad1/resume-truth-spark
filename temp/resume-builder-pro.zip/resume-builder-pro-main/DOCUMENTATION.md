# RESUMATE - Complete Technical & Product Documentation

**Version:** 1.0.0  
**Last Updated:** December 2024  
**Author:** Aditya Kittad  
**Purpose:** Permanent reference document for AI-assisted development continuity

---

## Table of Contents

1. [Product Overview](#1-product-overview)
2. [User Flows](#2-user-flows)
3. [Frontend Architecture](#3-frontend-architecture)
4. [Backend Architecture](#4-backend-architecture)
5. [Resume Generator Deep Dive](#5-resume-generator-deep-dive)
6. [ATS Scoring System](#6-ats-scoring-system)
7. [Database & Storage](#7-database--storage)
8. [AI Usage Policy](#8-ai-usage-policy)
9. [Deployment & Infrastructure](#9-deployment--infrastructure)
10. [Future Roadmap](#10-future-roadmap)
11. [How to Continue Development](#11-how-to-continue-development)

---

## 1. Product Overview

### 1.1 Startup Vision & Problem Statement

**Vision:** Democratize access to professional-grade, ATS-optimized resumes for students and freshers who cannot afford expensive resume services or lack knowledge of ATS systems.

**Problem Statement:**
1. 75%+ of resumes are rejected by ATS (Applicant Tracking Systems) before reaching human recruiters
2. Students and freshers do not understand ATS requirements: single-column layout, standard fonts, no graphics/tables
3. Existing resume builders either produce visually appealing but ATS-unfriendly resumes, or charge expensive subscription fees
4. Manual resume improvement is time-consuming and requires expertise most job seekers lack

### 1.2 Target Users

| User Segment | Characteristics | Primary Need |
|--------------|-----------------|--------------|
| College Students | Final year, applying for internships | Convert academic projects to professional experience |
| Fresh Graduates | 0-2 years experience | Structure limited experience effectively |
| Career Switchers | Changing industries | Highlight transferable skills |
| Internship Seekers | Looking for first professional experience | Build resume from scratch |

**Geographic Focus:** India (primary), with support for global users (15 country codes supported)

### 1.3 Core Value Proposition

**"Upload your resume → Get ATS score → See exactly what to fix → Download improved version in 2 minutes"**

Key benefits:
1. **Instant ATS Analysis:** Real-time scoring with specific, actionable feedback
2. **AI-Powered Enhancement:** Improve bullet points and summaries while maintaining authentic voice
3. **Zero Learning Curve:** No design skills needed; output is automatically ATS-compliant
4. **Free to Use:** No subscription barriers for students

### 1.4 Key Differentiators vs Competitors

| Feature | Resumate | Canva | Zety | LinkedIn Resume |
|---------|----------|-------|------|-----------------|
| ATS Score Before/After | ✅ | ❌ | ❌ | ❌ |
| AI Bullet Enhancement | ✅ | ❌ | ✅ (paid) | ❌ |
| Single-Column ATS Layout | ✅ Enforced | ❌ | Partial | ❌ |
| Free for Students | ✅ | Limited | ❌ | ✅ |
| Resume Upload + Parse | ✅ | ❌ | ❌ | ✅ |
| Score Comparison View | ✅ | ❌ | ❌ | ❌ |

### 1.5 What Makes This Product ATS-Safe and Trustworthy

**ATS-Safe Guarantees:**
1. **Single-column layout only:** No multi-column templates that confuse ATS parsers
2. **Standard fonts:** Serif (Georgia) or sans-serif (Helvetica, Arial) only
3. **No graphics/icons:** Pure text output with semantic HTML structure
4. **Standard section headers:** "Education", "Experience", "Skills" - no creative headers like "My Journey"
5. **Consistent date formatting:** "Month Year" format uniformly applied
6. **Bullet points as text:** `•` characters, not embedded images

**Trustworthy AI Approach:**
1. AI **enhances**, never **fabricates** content
2. Metrics are suggested as placeholders `[X%]` when not provided - user must verify
3. Original content preserved; enhancements are optional
4. No automatic submission to third parties
5. No persistent storage of resume data (privacy-first)

---

## 2. User Flows

### 2.1 Landing Page Flow

```
Step 1: User arrives at https://resumate.io/
Step 2: Landing page displays:
        - Resumate logo (animated bounce-in effect)
        - Headline: "Resumate"
        - Subheadline: "Create an ATS-friendly resume that gets past automated screening systems."
        - Primary CTA: "Create Your Resume" button
        - Footer: Copyright + LinkedIn link
Step 3: User clicks "Create Your Resume"
Step 4: Navigation to /generator route
Step 5: Page transition with fade animation
```

### 2.2 Resume Analysis Flow (Improve Existing Resume)

```
Step 1: User lands on /generator
Step 2: Mode Selection screen displays two cards:
        - "Start from Scratch" (left card)
        - "Improve Existing Resume" (right card)
Step 3: User hovers over "Improve Existing Resume" card
        - Card scales to 1.02
        - Gradient overlay appears
        - Shadow intensifies
Step 4: User clicks "Improve Existing Resume"
Step 5: State updates: step = 'upload', mode = 'improve'
Step 6: ResumeUploader component renders with tabs:
        - Tab 1: "Upload File" (drag-drop zone)
        - Tab 2: "Paste Text" (textarea)
Step 7: User either:
        a) Drags and drops PDF/DOC/DOCX/TXT file, OR
        b) Clicks "Browse Files" and selects file, OR
        c) Switches to "Paste Text" tab and pastes resume content
Step 8: File/text validation:
        - Supported types: PDF, DOC, DOCX, TXT
        - Maximum 50 pages for PDF
        - Minimum 50 characters for pasted text
Step 9: Progress bar animates (0% → 95%)
Step 10: Frontend sends request to parse-resume edge function:
         - For PDF/DOCX: fileBase64 + mimeType sent
         - For text: fileContent sent as string
Step 11: AI parses resume and extracts structured data:
         - contact: { name, email, phone, location, linkedin, github, portfolio }
         - summary: string
         - experience: [{ role, company, startDate, endDate, bullets[] }]
         - education: [{ degree, institution, graduationDate, gpa }]
         - skills: string[]
         - projects: [{ name, description, technologies[], link }]
         - certifications: [{ name, issuer, date, credentialId }]
Step 12: Progress bar completes (95% → 100%)
Step 13: Success toast: "Resume parsed successfully"
Step 14: State updates: step = 'improve'
Step 15: ImproveResumeFlow component renders with:
         - Score Comparison card (original score fetched)
         - ATS Analysis card (detailed breakdown)
         - Quick Actions panel
         - Live Preview / Edit Details tabs
Step 16: User sees original ATS score (e.g., 62%)
Step 17: ATS issues listed with severity: high/medium/low
Step 18: AI suggestions displayed with current vs suggested text
```

### 2.3 Resume Generator Flow (Start from Scratch)

```
Step 1: User on /generator selects "Start from Scratch"
Step 2: State updates: step = 'form', mode = 'scratch', resumeData = emptyResumeData
Step 3: ResumeForm component renders with 5-step wizard:
        - Step 1: Contact (name, email, phone, location with state/city dropdowns)
        - Step 2: Summary (textarea with AI enhance button)
        - Step 3: Experience (dynamic list with add/remove)
        - Step 4: Education (dynamic list with add/remove)
        - Step 5: Skills (tag input with comma/space/enter triggers)
Step 4: Progress indicator shows current step (1-5)
Step 5: User fills contact information:
        a) Full Name (required)
        b) Email (required)
        c) Phone with country code selector (15 countries)
        d) Location: State dropdown → City dropdown → "Other" option for custom city
Step 6: User clicks "Next"
Step 7: Summary step:
        a) User types professional summary
        b) User clicks "Enhance with AI" button
        c) Loading spinner appears
        d) AI returns improved summary
        e) User can accept or revert
Step 8: Experience step:
        a) User clicks "Add Experience"
        b) Empty experience card appears
        c) User fills: Role, Company, Start Date, End Date
        d) User adds bullet points
        e) For each bullet, "Enhance" button available
        f) User can reorder, delete experiences
Step 9: Education step:
        a) User clicks "Add Education"
        b) User fills: Degree, Institution, Graduation Date, GPA (optional)
        c) Multiple education entries supported
Step 10: Skills step:
         a) User types skill and presses Enter/comma/space
         b) Skill appears as badge/tag
         c) Click on tag removes it
Step 11: User clicks "Generate Resume"
Step 12: State updates: step = 'preview'
Step 13: ResumePreview component renders with A4-sized preview
```

### 2.4 ATS Score Before vs After Improvement

```
Step 1: ImproveResumeFlow mounts
Step 2: useEffect triggers fetchInitialScore()
Step 3: analyze-resume edge function called with initialData
Step 4: AI returns score (0-100) and suggestions
Step 5: originalScore state set (e.g., 62)
Step 6: currentScore state set to same value initially
Step 7: ScoreComparison component renders:
        - Left card: "Original" with score and color (green/yellow/red)
        - Arrow icon in center
        - Right card: "Current" with score and color
        - Bottom: Change indicator showing +/- points and percentage
Step 8: User makes improvements (edits text, applies AI suggestions)
Step 9: User clicks "Check Score" button in ScoreComparison header
Step 10: isCheckingScore = true, button shows loader
Step 11: analyze-resume called with current data state
Step 12: currentScore updated with new score
Step 13: ScoreComparison re-renders:
         - Original: 62% (unchanged, yellow)
         - Current: 78% (updated, green)
         - Change: "+16 points (+26%)" with green background
Step 14: Toast: "Score updated! Your current ATS score is 78%"
```

### 2.5 PDF Download Flow

```
Step 1: User in ResumePreview clicks "Download Resume" dropdown
Step 2: Dropdown menu shows 3 options:
        - PDF Format (best for sharing)
        - Word Document (easy to edit)
        - Plain Text (ATS optimized)
Step 3: User clicks "PDF Format"
Step 4: isGenerating = true, button shows loader
Step 5: Client-side PDF generation begins:
        a) New browser window opens
        b) HTML document generated with inline CSS styles
        c) Template styles applied based on selectedTemplate
        d) Window triggers print() on load
Step 6: Browser print dialog opens
Step 7: User selects "Save as PDF" in print dialog
Step 8: PDF saved with filename: "{Name}_Resume.pdf"
Step 9: Toast: "Print dialog opened. Save as PDF using your browser's print dialog."
Step 10: isGenerating = false, success checkmark briefly shown
```

### 2.6 Error States & Edge Cases

| Error State | Trigger | User Experience | Resolution |
|-------------|---------|-----------------|------------|
| Unsupported file type | Upload .exe, .zip, etc. | Toast: "Unsupported file type. Please upload PDF, DOC, DOCX, or TXT" | User uploads correct format |
| File too short | Paste <50 characters | Button disabled + "Text too short" toast | User pastes more content |
| AI rate limit | Too many requests | Toast: "Rate limit exceeded. Please try again in a moment." | Wait 60 seconds |
| AI credits exhausted | Account limit reached | Toast: "AI credits exhausted. Please add more credits." | Contact support |
| Parse failure | Corrupted PDF, binary file | Toast: "Failed to parse resume. Please try again or enter manually." | Retry or use scratch mode |
| Network error | No internet | Toast: "Could not analyze your resume. Please try again." | Check connection |
| Empty AI response | AI returns null | Toast: "Enhancement failed. Please try again." | Retry enhancement |

---

## 3. Frontend Architecture

### 3.1 Tech Stack

| Technology | Version | Purpose |
|------------|---------|---------|
| React | 18.3.1 | UI component library |
| TypeScript | 5.x | Type-safe JavaScript |
| Vite | 5.x | Build tool and dev server |
| Tailwind CSS | 3.x | Utility-first CSS framework |
| React Router DOM | 6.30.1 | Client-side routing |
| TanStack React Query | 5.83.0 | Server state management |
| Shadcn/UI | Latest | Component library (Radix primitives) |
| Lucide React | 0.462.0 | Icon library |
| Supabase JS | 2.89.0 | Backend client SDK |

### 3.2 Folder Structure with Purpose

```
src/
├── assets/                    # Static assets (images, logos)
│   └── resumate-new-logo.png  # Main application logo
│
├── components/                # Reusable UI components
│   ├── generator/             # Resume generator specific components
│   │   ├── ATSAnalysisCard.tsx       # Displays ATS score, issues, suggestions
│   │   ├── EnhancedResumeEditor.tsx  # Full resume editor with all sections
│   │   ├── ImproveResumeFlow.tsx     # Main flow for "Improve Existing Resume"
│   │   ├── ModeSelector.tsx          # "Scratch" vs "Improve" selection cards
│   │   ├── ResumeForm.tsx            # Step-by-step form for new resumes
│   │   ├── ResumePreview.tsx         # Final preview with download options
│   │   ├── ResumeTemplates.tsx       # Template definitions and renderer
│   │   ├── ResumeUploader.tsx        # File upload + paste text component
│   │   ├── ScoreComparison.tsx       # Before/after score visualization
│   │   └── TemplateSelector.tsx      # Template style picker grid
│   │
│   └── ui/                    # Shadcn/UI components (40+ components)
│       ├── button.tsx         # Button variants
│       ├── card.tsx           # Card container
│       ├── input.tsx          # Text input
│       ├── textarea.tsx       # Multi-line input
│       ├── select.tsx         # Dropdown select
│       ├── badge.tsx          # Tag/badge display
│       ├── progress.tsx       # Progress bar
│       ├── tabs.tsx           # Tabbed interface
│       ├── collapsible.tsx    # Expandable sections
│       ├── dropdown-menu.tsx  # Dropdown menus
│       ├── toast.tsx          # Notification toasts
│       ├── skeleton.tsx       # Loading skeletons
│       └── ... (35+ more)
│
├── data/                      # Static data files
│   └── indianLocations.ts     # State/city data for India (29 states, 500+ cities)
│
├── hooks/                     # Custom React hooks
│   ├── use-mobile.tsx         # Mobile detection hook
│   └── use-toast.ts           # Toast notification hook
│
├── integrations/              # External service integrations
│   └── supabase/
│       ├── client.ts          # Supabase client instance (auto-generated)
│       └── types.ts           # Database types (auto-generated)
│
├── lib/                       # Utility functions
│   └── utils.ts               # cn() classname merger, general utilities
│
├── pages/                     # Route-level page components
│   ├── Index.tsx              # Landing page (/)
│   ├── Generator.tsx          # Main generator page (/generator)
│   └── NotFound.tsx           # 404 page
│
├── types/                     # TypeScript type definitions
│   └── resume.ts              # ResumeData, ResumeExperience, etc.
│
├── App.tsx                    # Root component with routing
├── App.css                    # Global CSS (minimal)
├── index.css                  # Tailwind + design system variables
├── main.tsx                   # React entry point
└── vite-env.d.ts              # Vite type declarations
```

### 3.3 Page-by-Page Explanation

#### 3.3.1 Landing Page (`src/pages/Index.tsx`)

**Route:** `/`

**Purpose:** Hero page that introduces Resumate and drives users to the generator.

**Structure:**
```tsx
<div className="flex min-h-screen flex-col bg-background">
  <main>              // Centered content area
    <img />           // Logo with bounce-in animation
    <h1 />            // "Resumate" title
    <p />             // Value proposition subtitle
    <Link to="/generator">
      <Button />      // Primary CTA
    </Link>
  </main>
  <footer>            // Copyright + LinkedIn link
  </footer>
</div>
```

**Key Features:**
- Full-height layout with centered content
- Staggered fade-in animations (100ms, 200ms, 300ms delays)
- LinkedIn button with hover color transition to #0077B5

#### 3.3.2 Generator Page (`src/pages/Generator.tsx`)

**Route:** `/generator`

**Purpose:** Main application flow orchestrator managing step state.

**State Machine:**
```
type GeneratorStep = 'select' | 'upload' | 'improve' | 'form' | 'preview';

State transitions:
- 'select' → 'form' (if mode = 'scratch')
- 'select' → 'upload' (if mode = 'improve')
- 'upload' → 'improve' (after successful parse)
- 'improve' → 'preview' (on complete)
- 'form' → 'preview' (on submit)
- Any → previous step (on back)
```

**Component Rendering by Step:**
| Step | Component | Description |
|------|-----------|-------------|
| select | ModeSelector | Two cards for mode choice |
| upload | ResumeUploader | File upload or paste interface |
| improve | ImproveResumeFlow | ATS analysis + editor |
| form | ResumeForm | 5-step form wizard |
| preview | ResumePreview | Final resume with download |

#### 3.3.3 Not Found Page (`src/pages/NotFound.tsx`)

**Route:** `*` (catch-all)

**Purpose:** 404 error page for undefined routes.

### 3.4 Component Responsibilities

| Component | Responsibility | Props | State |
|-----------|---------------|-------|-------|
| ModeSelector | Display mode selection cards | onSelectMode: (mode) => void | hoveredCard: 'scratch' \| 'improve' \| null |
| ResumeUploader | Handle file upload/paste + parsing | onParsed, onBack | isLoading, uploadStatus, pastedText |
| ImproveResumeFlow | Orchestrate improvement flow | initialData, onComplete, onBack | data, originalScore, currentScore, suggestions, selectedTemplate |
| ATSAnalysisCard | Display ATS analysis results | resumeData, onScoreUpdate, onSuggestionsReady | analysis, isLoading, error |
| ScoreComparison | Visualize score before/after | originalScore, currentScore, onCheckScore, isChecking | (none - pure display) |
| EnhancedResumeEditor | Full section-by-section editor | data, onChange | enhancingField, sectionsOpen, skillInput, techInput |
| ResumeForm | Multi-step form wizard | initialData, onSubmit, onBack | data, currentStep, countryCode, selectedState, selectedCity |
| ResumePreview | Display final resume + downloads | data, onBack, onEdit, selectedTemplate | isGenerating, downloadFormat, templateOpen |
| ResumeTemplates | Render resume in selected style | data, templateId | (none - pure renderer) |
| TemplateSelector | Grid of template choices | selectedTemplate, onSelectTemplate | (none - pure display) |

### 3.5 State Management Approach

**Local State Only:** This application uses React's built-in `useState` and `useEffect` hooks. No global state management library (Redux, Zustand, etc.) is needed because:

1. **State is localized:** Each flow (improve vs scratch) has its own state
2. **No cross-page state:** Navigation between pages is unidirectional
3. **Server state handled by Supabase:** API calls managed through `supabase.functions.invoke()`
4. **No persistence required:** Resume data is not saved (privacy-first)

**State Flow Pattern:**
```
Generator (orchestrator state: step, mode)
  ↓ props
  └→ ImproveResumeFlow (data, scores, suggestions)
       ↓ props
       ├→ ATSAnalysisCard (analysis results)
       ├→ ScoreComparison (score display)
       ├→ EnhancedResumeEditor (editing state)
       └→ ResumePreview (download state)
```

### 3.6 How Preview + Edit Mode Works

**ImproveResumeFlow Tab System:**

```tsx
<Tabs value={activeTab} onValueChange={setActiveTab}>
  <TabsList>
    <TabsTrigger value="analysis">Live Preview</TabsTrigger>
    <TabsTrigger value="edit">Edit Details</TabsTrigger>
  </TabsList>
  
  <TabsContent value="analysis">
    <TemplateSelector />           // Choose visual style
    <ResumeTemplateRenderer />     // A4-sized preview
  </TabsContent>
  
  <TabsContent value="edit">
    <EnhancedResumeEditor />       // Section-by-section editor
  </TabsContent>
</Tabs>
```

**Data Flow:**
1. User edits in "Edit Details" tab
2. `onChange(data)` updates `data` state in parent
3. "Live Preview" tab re-renders with new data
4. ResumeTemplateRenderer receives updated `data` prop
5. Preview reflects changes immediately (no save button)

### 3.7 How Animations Are Layered Safely

**Animation Strategy:**
1. **CSS-first animations:** All animations defined in `index.css` using `@keyframes`
2. **Tailwind utility classes:** `animate-fade-in`, `animate-scale-in`, etc.
3. **Delay classes:** `delay-100`, `delay-200`, ... `delay-500` for staggered effects
4. **Initial opacity 0:** Elements start invisible, animation reveals them

**Accessibility:**
```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

**Animation Types Used:**
| Animation | Duration | Easing | Use Case |
|-----------|----------|--------|----------|
| fade-in | 0.5s | ease-out | General content appearance |
| fade-in-up | 0.6s | ease-out | Cards, sections entering from below |
| scale-in | 0.4s | ease-out | Modals, previews |
| bounce-in | 0.6s | cubic-bezier | Logo, success icons |
| float | 3s infinite | ease-in-out | Decorative elements |
| shimmer | 2s infinite | linear | Loading states |

---

## 4. Backend Architecture

### 4.1 Why Backend is Split from Frontend

**Separation Rationale:**

1. **Security:** API keys (LOVABLE_API_KEY) must never be exposed to client-side code
2. **Cost Control:** AI API calls are rate-limited and metered server-side
3. **Validation:** Resume parsing and enhancement must be validated before returning
4. **Privacy:** Sensitive resume data processed in isolated serverless environment
5. **Scalability:** Edge functions scale independently based on demand

**Architecture Pattern:**
```
┌─────────────────┐    HTTPS     ┌──────────────────────┐
│  React Frontend │ ────────────►│  Supabase Edge       │
│  (Vite + SPA)   │              │  Functions (Deno)    │
└─────────────────┘              └──────────────────────┘
                                          │
                                          ▼
                                 ┌──────────────────────┐
                                 │  Lovable AI Gateway  │
                                 │  (google/gemini-2.5-flash) │
                                 └──────────────────────┘
```

### 4.2 API Contracts

#### 4.2.1 Parse Resume Service

**Endpoint:** `POST /functions/v1/parse-resume`

**Request:**
```typescript
// Option A: File upload (PDF/DOCX)
{
  fileName: string;       // "resume.pdf"
  fileBase64: string;     // Base64 encoded file content
  mimeType: string;       // "application/pdf"
}

// Option B: Text input
{
  fileName: string;       // "Pasted Resume"
  fileContent: string;    // Raw text content
}
```

**Response (Success - 200):**
```typescript
{
  contact: {
    name: string;         // "John Doe"
    email: string;        // "john@example.com"
    phone: string;        // "+91 9876543210"
    location: string;     // "Mumbai, Maharashtra"
    linkedin?: string;    // "linkedin.com/in/johndoe"
    github?: string;      // "github.com/johndoe"
    portfolio?: string;   // "johndoe.dev"
  };
  summary: string;        // Professional summary paragraph
  experience: Array<{
    role: string;         // "Software Engineer"
    company: string;      // "Tech Corp"
    startDate: string;    // "Jan 2022"
    endDate: string;      // "Present"
    bullets: string[];    // ["Led development of...", "Increased..."]
  }>;
  education: Array<{
    degree: string;       // "B.Tech Computer Science"
    institution: string;  // "MIT Aurangabad"
    graduationDate: string; // "May 2027"
    gpa?: string;         // "8.5/10"
  }>;
  skills: string[];       // ["React", "Node.js", "Python"]
  projects: Array<{
    name: string;         // "AI Automation System"
    description: string;  // "Built workflow engine..."
    technologies: string[]; // ["Docker", "Python"]
    link?: string;        // "github.com/..."
  }>;
  certifications: Array<{
    name: string;         // "AWS Certified"
    issuer: string;       // "Amazon"
    date: string;         // "2024"
    credentialId?: string; // "ABC123"
  }>;
}
```

**Response (Error - 400/429/402/500):**
```typescript
{
  error: string;  // Human-readable error message
}
```

#### 4.2.2 Analyze Resume Service

**Endpoint:** `POST /functions/v1/analyze-resume`

**Request:**
```typescript
{
  resumeData: ResumeData  // Full resume data object
}
```

**Response (Success - 200):**
```typescript
{
  score: number;          // 0-100
  issues: Array<{
    category: "formatting" | "content" | "keywords" | "structure";
    severity: "high" | "medium" | "low";
    message: string;      // "Missing quantified achievements in experience"
    section?: string;     // "experience"
  }>;
  suggestions: Array<{
    section: string;      // "summary"
    current: string;      // "Built websites"
    suggested: string;    // "Engineered 15+ responsive web applications..."
    reason: string;       // "Added quantifiable metrics and action verbs"
  }>;
  strengths: string[];    // ["Clear section headers", "Relevant skills"]
  keywords: {
    found: string[];      // ["React", "JavaScript"]
    missing: string[];    // ["TypeScript", "AWS"]
  };
}
```

#### 4.2.3 Enhance Content Service

**Endpoint:** `POST /functions/v1/enhance-content`

**Request:**
```typescript
{
  content: string;        // Text to enhance
  type: "summary" | "bullet";  // Content type
}
```

**Response (Success - 200):**
```typescript
{
  enhanced: string;       // Improved text
}
```

#### 4.2.4 Generate PDF Service

**Endpoint:** `POST /functions/v1/generate-pdf`

**Request:**
```typescript
{
  resumeData: ResumeData  // Full resume data object
}
```

**Response (Success - 200):**
```typescript
{
  textContent: string;    // Plain text resume (ATS-optimized)
  resumeData: ResumeData; // Echo back for verification
}
```

### 4.3 ATS Score Calculation Logic (High Level)

**Scoring Criteria (100 points total):**

| Criterion | Points | What AI Checks |
|-----------|--------|----------------|
| Contact Info Completeness | 10 | Name, email, phone, location present |
| Professional Summary Quality | 15 | Length (2-3 sentences), keywords, impact |
| Experience with Quantified Achievements | 30 | Action verbs, metrics, specificity |
| Action Verbs Usage | 10 | Starting bullets with strong verbs |
| Skills Section Relevance | 15 | Keyword density, organization |
| Education Completeness | 10 | Degree, institution, dates |
| Overall Formatting/Structure | 10 | Section order, consistency |

**Score Interpretation:**
- 80-100: Excellent (green) - Highly ATS-compatible
- 60-79: Good (yellow) - Needs minor improvements
- 40-59: Needs Work (orange) - Significant issues
- 0-39: Poor (red) - Major restructuring needed

### 4.4 Error Handling & Validation Logic

**Edge Function Error Handling Pattern:**
```typescript
try {
  // Parse request
  const { resumeData } = await req.json();
  
  // Validate input
  if (!resumeData) {
    return new Response(
      JSON.stringify({ error: 'Resume data is required' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
  
  // Check for required secrets
  const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
  if (!LOVABLE_API_KEY) {
    throw new Error('LOVABLE_API_KEY is not configured');
  }
  
  // Call AI API
  const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {...});
  
  // Handle AI errors
  if (!response.ok) {
    if (response.status === 429) {
      return new Response(
        JSON.stringify({ error: 'Rate limit exceeded. Please try again in a moment.' }),
        { status: 429, headers: corsHeaders }
      );
    }
    if (response.status === 402) {
      return new Response(
        JSON.stringify({ error: 'AI credits exhausted. Please add more credits.' }),
        { status: 402, headers: corsHeaders }
      );
    }
    throw new Error(`AI gateway error: ${response.status}`);
  }
  
  // Parse and validate AI response
  const aiResponse = await response.json();
  const content = aiResponse.choices?.[0]?.message?.content;
  
  if (!content) {
    throw new Error('No response from AI');
  }
  
  // Extract JSON from response (handle markdown code blocks)
  let jsonContent = content.trim();
  if (jsonContent.startsWith('```json')) jsonContent = jsonContent.slice(7);
  if (jsonContent.endsWith('```')) jsonContent = jsonContent.slice(0, -3);
  
  // Parse and return
  const parsed = JSON.parse(jsonContent);
  return new Response(JSON.stringify(parsed), { headers: corsHeaders });
  
} catch (error) {
  console.error('Error:', error);
  return new Response(
    JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error occurred' }),
    { status: 500, headers: corsHeaders }
  );
}
```

---

## 5. Resume Generator Deep Dive

### 5.1 Data Model of a Resume

**TypeScript Definition (`src/types/resume.ts`):**

```typescript
export interface ResumeContact {
  name: string;           // Required
  email: string;          // Required
  phone: string;          // Required (with country code)
  location: string;       // Required (City, State format)
  linkedin?: string;      // Optional
  github?: string;        // Optional
  portfolio?: string;     // Optional
}

export interface ResumeExperience {
  id: string;             // Unique identifier (exp-{timestamp})
  role: string;           // Job title
  company: string;        // Company name
  startDate: string;      // "Month Year" format
  endDate: string;        // "Month Year" or "Present"
  bullets: string[];      // Achievement/responsibility list
}

export interface ResumeEducation {
  id: string;             // Unique identifier (edu-{timestamp})
  degree: string;         // e.g., "B.Tech Computer Science"
  institution: string;    // School/university name
  graduationDate: string; // "Month Year" or "Expected Month Year"
  gpa?: string;           // Optional GPA
}

export interface ResumeProject {
  id: string;             // Unique identifier (proj-{timestamp})
  name: string;           // Project name
  description: string;    // Brief description
  technologies: string[]; // Tech stack used
  link?: string;          // Project URL
}

export interface ResumeCertification {
  id: string;             // Unique identifier (cert-{timestamp})
  name: string;           // Certification name
  issuer: string;         // Issuing organization
  date: string;           // Issue date
  credentialId?: string;  // Optional credential ID
}

export interface ResumeData {
  contact: ResumeContact;
  summary: string;
  experience: ResumeExperience[];
  education: ResumeEducation[];
  skills: string[];
  projects: ResumeProject[];
  certifications: ResumeCertification[];
}

export const emptyResumeData: ResumeData = {
  contact: {
    name: '',
    email: '',
    phone: '',
    location: '',
    linkedin: '',
    github: '',
    portfolio: '',
  },
  summary: '',
  experience: [],
  education: [],
  skills: [],
  projects: [],
  certifications: [],
};
```

### 5.2 How Uploaded Resume is Parsed

**Step-by-Step Process:**

1. **File Selection:** User uploads via drag-drop or file picker
2. **File Type Detection:**
   ```typescript
   const isPdf = file.type === 'application/pdf' || file.name.endsWith('.pdf');
   const isDocx = file.name.endsWith('.docx');
   const isDoc = file.name.endsWith('.doc');
   ```
3. **File Encoding:**
   - PDF/DOCX: Convert to Base64 using FileReader
   - TXT: Read as plain text
4. **Request Construction:**
   ```typescript
   // Binary files
   { fileName, fileBase64: base64Content, mimeType: 'application/pdf' }
   
   // Text files
   { fileName, fileContent: textContent }
   ```
5. **AI Processing (parse-resume edge function):**
   - For PDF: Uses Gemini's vision capability with base64 image
   - For text: Direct text parsing
6. **Structured Extraction:**
   - AI prompted with exact JSON schema
   - Temperature set to 0.1 for consistent output
   - Response parsed and validated
7. **ID Generation:**
   ```typescript
   experience.map((exp, idx) => ({ ...exp, id: `exp-${idx}-${Date.now()}` }))
   ```

### 5.3 How Data Auto-Fills the Editor

**Flow After Parse:**

```typescript
// In ResumeUploader.tsx
const resumeData: ResumeData = {
  contact: data.contact || { name: '', email: '', phone: '', location: '' },
  summary: data.summary || '',
  experience: (data.experience || []).map((exp, idx) => ({
    ...exp,
    id: `exp-${idx}-${Date.now()}`,  // Generate unique IDs
  })),
  education: (data.education || []).map((edu, idx) => ({
    ...edu,
    id: `edu-${idx}-${Date.now()}`,
  })),
  skills: data.skills || [],
  projects: (data.projects || []).map((proj, idx) => ({
    ...proj,
    id: `proj-${idx}-${Date.now()}`,
  })),
  certifications: (data.certifications || []).map((cert, idx) => ({
    ...cert,
    id: `cert-${idx}-${Date.now()}`,
  })),
};

// Pass to parent
onParsed(resumeData);

// In Generator.tsx
const handleParsedResume = (data: ResumeData) => {
  setResumeData(data);     // Store in state
  setStep('improve');      // Navigate to improve flow
};

// In ImproveResumeFlow.tsx
<EnhancedResumeEditor data={data} onChange={setData} />
// Editor receives data as prop, renders all fields pre-filled
```

### 5.4 AI Enhancement Rules

**What AI CAN Change:**

| Content Type | Allowed Changes | Example |
|--------------|-----------------|---------|
| Summary | Strengthen language, add keywords | "Developer" → "Full-stack developer with expertise in..." |
| Bullet points | Add action verbs, quantify achievements | "Worked on website" → "Engineered responsive web application serving 10K+ users" |
| Writing style | Make more professional/impactful | Passive → Active voice |

**What AI CANNOT Change:**

| Content Type | Protected Elements | Reason |
|--------------|-------------------|--------|
| Factual data | Company names, job titles, dates | Legal accuracy |
| Contact info | Email, phone, address | Identity verification |
| Education | Degrees, institutions, GPA | Credential verification |
| Made-up metrics | AI adds [X%] placeholders | User must verify real numbers |

**AI Enhancement Prompts:**

```typescript
// Summary enhancement
systemPrompt = `You are an expert resume writer who helps craft compelling professional summaries.
Your task is to enhance the given professional summary to be:
- More impactful and engaging while maintaining a natural, humanized tone
- ATS-friendly with relevant keywords
- Concise (2-3 sentences max)
- Written in first person without using "I"
- Professional but not robotic or overly formal

Return ONLY the enhanced summary text, nothing else.`;

// Bullet point enhancement
systemPrompt = `You are an expert resume writer who creates powerful achievement bullets.
Your task is to enhance the given job responsibility/achievement to be:
- Action-oriented, starting with a strong action verb
- Quantified with metrics where possible (add realistic placeholders like [X%] if none provided)
- More impactful while maintaining a natural, humanized tone
- ATS-friendly with relevant keywords
- Concise (1 sentence, under 20 words ideally)

Return ONLY the enhanced bullet point text, nothing else.`;
```

### 5.5 ATS Enforcement Rules

**Font Enforcement:**
```typescript
const templateStyles = {
  classic: {
    container: "font-serif bg-white",  // Georgia, serif
    // ...
  },
  modern: {
    container: "font-sans bg-white",   // Helvetica, Arial, sans-serif
    // ...
  },
  // All templates use only standard, ATS-safe fonts
};
```

**Layout Enforcement:**
- Single column only (no multi-column layouts)
- A4 dimensions: 210mm x 297mm
- Consistent margins: 15mm top/bottom, 20mm left/right
- Section order: Education → Skills → Experience → Projects → Certifications

**Structure Enforcement:**
```typescript
// Section headers are standardized
<h2>Education</h2>           // Not "Learning Journey"
<h2>Technical Skills</h2>    // Not "What I Know"
<h2>Experience</h2>          // Not "My Career Path"
<h2>Projects</h2>            // Not "Cool Things I Built"
<h2>Certifications</h2>      // Not "Badges"
```

**Text Formatting:**
- No tables, columns, or graphics
- Plain bullet points using `•` character
- Consistent date format: "Month Year" (e.g., "Jan 2024")
- No colored text (black/gray only)

### 5.6 Preview → Edit → Regenerate Flow

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Live Preview   │ ──► │   Edit Details  │ ──► │  Live Preview   │
│  (read-only)    │     │   (editable)    │     │  (updated)      │
└─────────────────┘     └─────────────────┘     └─────────────────┘
        │                       │                       │
        ▼                       ▼                       ▼
   View resume            Modify data              See changes
   Select template        AI enhance               Check ATS score
   Identify issues        Add/remove items         Download PDF
```

**Data Synchronization:**
```typescript
// In EnhancedResumeEditor
const updateExperience = (id, field, value) => {
  onChange({                    // Notify parent
    ...data,
    experience: data.experience.map(exp =>
      exp.id === id ? { ...exp, [field]: value } : exp
    )
  });
};

// In ImproveResumeFlow
<EnhancedResumeEditor 
  data={data}                  // Current state
  onChange={setData}           // State updater
/>

// Changes immediately reflected in:
<ResumeTemplateRenderer 
  data={data}                  // Same state
  templateId={selectedTemplate} 
/>
```

---

## 6. ATS Scoring System

### 6.1 What ATS Checks For

**Applicant Tracking Systems parse resumes for:**

| Check | What ATS Looks For | Common Failures |
|-------|-------------------|-----------------|
| **Parsing** | Machine-readable text | Images of text, tables, columns |
| **Keywords** | Job-relevant terms | Missing industry terms |
| **Structure** | Standard section headers | Creative/custom headers |
| **Formatting** | Consistent layout | Mixed fonts, colors, sizes |
| **Contact** | Valid email, phone | Missing or malformed |
| **Experience** | Chronological order | Random date ordering |
| **Achievements** | Quantified results | Vague responsibilities |

### 6.2 How Scores Are Calculated

**Resumate's Scoring Algorithm (AI-based):**

```
Total Score = Sum of all category scores (max 100)

Category Breakdown:
├── Contact Info Completeness (10 pts)
│   ├── Name present: 2 pts
│   ├── Email valid: 2 pts
│   ├── Phone with code: 2 pts
│   ├── Location specified: 2 pts
│   └── LinkedIn/GitHub: 2 pts (bonus)
│
├── Professional Summary (15 pts)
│   ├── Present and non-empty: 5 pts
│   ├── 2-3 sentences: 3 pts
│   ├── Contains keywords: 4 pts
│   └── Action-oriented: 3 pts
│
├── Experience Quality (30 pts)
│   ├── Has experience entries: 5 pts
│   ├── Each entry complete: 5 pts
│   ├── Bullets start with action verbs: 10 pts
│   └── Quantified achievements: 10 pts
│
├── Action Verbs Usage (10 pts)
│   ├── Strong verbs: "Engineered", "Led", "Developed"
│   └── Weak verbs: "Worked on", "Helped with"
│
├── Skills Section (15 pts)
│   ├── Skills present: 5 pts
│   ├── Relevant to target field: 5 pts
│   └── Well-organized: 5 pts
│
├── Education (10 pts)
│   ├── Degree specified: 3 pts
│   ├── Institution named: 3 pts
│   ├── Dates included: 2 pts
│   └── GPA if strong: 2 pts (bonus)
│
└── Formatting/Structure (10 pts)
    ├── Consistent formatting: 5 pts
    └── Logical section order: 5 pts
```

### 6.3 Common Mistakes Detected

**High Severity Issues:**
- Missing contact information
- No professional experience listed
- Empty skills section
- Resume too short (<100 words)

**Medium Severity Issues:**
- Generic summary ("Hard-working professional...")
- Bullets without metrics
- Inconsistent date formats
- Missing action verbs

**Low Severity Issues:**
- Optional fields empty (LinkedIn, GitHub)
- GPA not listed
- Minor formatting inconsistencies

### 6.4 How Improvement Changes the Score

**Example Transformation:**

| Section | Before | After | Points Gained |
|---------|--------|-------|---------------|
| Summary | "I am a developer" | "Full-stack developer with 2+ years building scalable web applications" | +8 |
| Bullet | "Worked on website" | "Engineered responsive web platform serving 10K+ monthly users" | +10 |
| Skills | "Coding" | "JavaScript, React, Node.js, Python, PostgreSQL" | +7 |
| Total | 52% | 77% | +25 |

### 6.5 Why the System Avoids Fake or Inflated Scores

**Integrity Measures:**

1. **AI Prompt Design:**
   ```
   "Be specific and actionable in your feedback. Focus on:
   1. Missing quantifiable metrics in bullet points
   2. Weak or passive language
   3. Missing important keywords
   4. Formatting issues
   5. Content gaps"
   ```

2. **Placeholder Markers:**
   - When AI adds metrics, it uses `[X%]` format
   - User must replace with real numbers
   - Teaches user to quantify without lying

3. **No Auto-Inflate:**
   - System reports actual issues
   - Score only increases when real improvements made
   - "Check Score" button requires re-analysis

4. **Conservative Defaults:**
   - New items start without scores
   - Missing fields reduce score
   - No points for empty content

---

## 7. Database & Storage

### 7.1 What Is Stored

**Current Storage:**

| Data Type | Storage Location | Retention |
|-----------|-----------------|-----------|
| Uploaded files | Supabase Storage (`resume-uploads` bucket) | Temporary (session only) |
| Parsed resume data | Browser memory (React state) | Until page refresh |
| User preferences | None | Not stored |
| Generated PDFs | Client-side download | Not stored server-side |

### 7.2 What Is Never Stored

**Privacy-First Design:**

| Data Type | Why Not Stored | Alternative |
|-----------|---------------|-------------|
| Resume content | Privacy concern | Process in memory, return to client |
| Personal contact info | GDPR/privacy | Client-side only |
| AI prompts/responses | Cost + privacy | Processed and discarded |
| User accounts | Simplicity | No login required |
| Download history | Not needed | No tracking |

### 7.3 Temporary Storage for Uploads

**Upload Bucket Configuration:**

```toml
# Bucket: resume-uploads
Is Public: No (private)
Purpose: Temporary file storage during processing
```

**Flow:**
1. User uploads file → Stored temporarily in browser memory
2. File converted to Base64 → Sent to edge function
3. Edge function processes → Returns structured data
4. Original file discarded → Only parsed data remains in client state

### 7.4 Security & Cleanup Approach

**Security Measures:**

1. **No persistent storage:** Resume data exists only in browser session
2. **HTTPS only:** All API calls encrypted in transit
3. **Private bucket:** Storage bucket not publicly accessible
4. **No logging of content:** Edge functions log errors, not resume content
5. **CORS headers:** API restricted to known origins

**Cleanup:**
- Browser refresh clears all resume data
- No database entries to clean up
- Edge function logs auto-expire per Supabase policies

---

## 8. AI Usage Policy

### 8.1 Where AI Is Used

| Feature | AI Model | Purpose |
|---------|----------|---------|
| Resume Parsing | google/gemini-2.5-flash | Extract structured data from uploaded files |
| ATS Analysis | google/gemini-2.5-flash | Score resume and identify issues |
| Summary Enhancement | google/gemini-2.5-flash | Improve professional summary text |
| Bullet Enhancement | google/gemini-2.5-flash | Strengthen achievement statements |

### 8.2 Where AI Is NOT Used

| Feature | Reason |
|---------|--------|
| Contact information | Must be exact user input |
| Dates | User-provided, not AI-generated |
| Company names | Factual data, no AI modification |
| Final PDF rendering | Client-side template rendering |
| Score calculation | AI provides score, but criteria are fixed |
| User authentication | No accounts, no AI involvement |

### 8.3 Guardrails to Prevent Hallucinations

**Prompt Engineering:**

```typescript
// Strict instruction to prevent fabrication
systemPrompt = `You are a resume parser that extracts structured data from resumes.
You MUST respond with ONLY a valid JSON object, no other text.
Extract ONLY what is explicitly written in the resume. 
Do NOT invent or hallucinate any information.
If a field is not present, use empty string "" for strings or empty array [] for arrays.`;
```

**Response Validation:**

```typescript
// Ensure all fields exist, default to empty
parsedResume = {
  contact: {
    name: parsedResume.contact?.name || '',
    email: parsedResume.contact?.email || '',
    // ... fallbacks for all fields
  },
  summary: parsedResume.summary || '',
  experience: Array.isArray(parsedResume.experience) ? parsedResume.experience : [],
  // ... validate all arrays
};
```

**Metric Placeholders:**
```typescript
// When AI adds metrics, it uses placeholders
"Quantified with metrics where possible (add realistic placeholders like [X%] if none provided)"
// Output: "Increased performance by [X%]"
// User sees placeholder and knows to verify/replace
```

### 8.4 How AI Suggestions Are Validated

**Validation Steps:**

1. **JSON Structure Check:** Response must be valid JSON
2. **Field Presence Check:** All required fields must exist
3. **Type Validation:** Arrays must be arrays, strings must be strings
4. **Length Limits:** Suggestions capped at reasonable lengths
5. **Display for User Review:** User sees current vs suggested, decides to apply

### 8.5 Student-Safe AI Design

**Design Principles:**

1. **No hallucinated experience:** AI cannot invent jobs or achievements
2. **Placeholder metrics:** `[X%]` forces user verification
3. **Original preserved:** User can always revert to original content
4. **Transparent suggestions:** Shows exactly what changes and why
5. **No auto-submit:** User controls when to download/share

---

## 9. Deployment & Infrastructure

### 9.1 Repository Structure

**Single Monorepo:**
```
resumate/
├── src/                      # Frontend React application
├── supabase/
│   ├── functions/            # Edge functions (Deno runtime)
│   │   ├── analyze-resume/
│   │   ├── enhance-content/
│   │   ├── generate-pdf/
│   │   └── parse-resume/
│   └── config.toml           # Supabase configuration
├── public/                   # Static assets
├── package.json              # Frontend dependencies
├── vite.config.ts            # Vite configuration
├── tailwind.config.ts        # Tailwind configuration
└── tsconfig.json             # TypeScript configuration
```

### 9.2 Environment Variables

**Frontend (.env - auto-generated by Lovable Cloud):**
```env
VITE_SUPABASE_URL=https://yizmyujmuwjjefprhjhj.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
VITE_SUPABASE_PROJECT_ID=yizmyujmuwjjefprhjhj
```

**Backend (Supabase Secrets):**
```
LOVABLE_API_KEY        # AI gateway authentication
SUPABASE_URL           # Supabase project URL
SUPABASE_ANON_KEY      # Public anon key
SUPABASE_SERVICE_ROLE_KEY  # Admin key (for internal use)
```

### 9.3 Hosting Strategy

**Frontend:**
- Hosted on Lovable Cloud
- Static SPA deployed via Vite build
- CDN-backed for global distribution
- Custom domain support available

**Backend:**
- Supabase Edge Functions (Deno runtime)
- Auto-scaling serverless functions
- No cold start concerns (functions are warm)
- Region: Determined by Supabase project

**AI Gateway:**
- Lovable AI Gateway (`ai.gateway.lovable.dev`)
- Abstracts AI provider (currently Google Gemini)
- Rate limiting and cost control managed

### 9.4 How to Safely Add New Features

**Feature Addition Checklist:**

1. **Frontend Component:**
   - Create in `src/components/generator/` if resume-related
   - Follow existing component patterns
   - Add proper TypeScript interfaces
   - Test with mock data before API integration

2. **Backend Function:**
   - Create folder in `supabase/functions/`
   - Add `index.ts` with proper CORS headers
   - Include error handling for 400/429/402/500
   - Update `config.toml` if needed

3. **Type Updates:**
   - Modify `src/types/resume.ts` for data model changes
   - Update edge function interfaces to match
   - Ensure backward compatibility with existing data

4. **Testing:**
   - Test with empty data
   - Test with maximum data
   - Test error scenarios
   - Test on mobile viewport

### 9.5 Rollback Strategy

**Frontend Rollback:**
1. Lovable maintains version history
2. Navigate to project settings
3. Restore to previous version
4. Automatic redeployment

**Backend Rollback:**
1. Edge functions auto-deploy on code push
2. Revert code changes in repository
3. Functions automatically redeploy

**Database Rollback:**
- N/A: No database tables in use
- Storage bucket data is ephemeral

---

## 10. Future Roadmap

### 10.1 Paid Features Potential

| Feature | Description | Monetization Model |
|---------|-------------|-------------------|
| Premium Templates | 10+ additional professional designs | One-time purchase $5 |
| Unlimited AI Enhancements | Remove rate limits | Subscription $3/month |
| Job Description Matching | Tailor resume to specific job | Per-use $1 |
| Cover Letter Generator | AI-powered cover letters | Per-use $2 |
| Resume Storage | Save and edit multiple versions | Subscription $5/month |

### 10.2 Recruiter Dashboards

**Potential Features:**
- View candidate resumes in standardized format
- Filter by skills, experience level, location
- ATS score as ranking metric
- Bulk resume parsing for HR teams

### 10.3 Resume Versioning

**Planned Implementation:**
- Save multiple versions of same resume
- Name versions (e.g., "Tech Companies", "Startups")
- Compare versions side-by-side
- Track changes over time

### 10.4 Job Matching

**Concept:**
1. User pastes job description
2. AI analyzes JD for required skills/keywords
3. Compare against resume
4. Show match percentage
5. Suggest specific improvements to increase match

### 10.5 Interview Prep

**Potential Features:**
- Generate likely interview questions from resume
- Practice answers with AI feedback
- Mock interview simulations
- Company research integration

### 10.6 Analytics

**Potential Metrics:**
- Resume download counts
- ATS score improvement trends
- Most common issues detected
- Feature usage patterns

---

## 11. How to Continue Development

### 11.1 How a New Developer Can Understand the Project

**Onboarding Steps:**

1. **Read this document completely** - Contains all architectural decisions
2. **Explore folder structure:**
   ```
   src/pages/          → Entry points (Index.tsx, Generator.tsx)
   src/components/     → UI components (start with generator/)
   src/types/          → Data models (resume.ts is key)
   supabase/functions/ → Backend logic
   ```
3. **Trace user flow:**
   - Start at `Generator.tsx`
   - Follow `step` state transitions
   - Understand component mounting/unmounting
4. **Run locally:**
   ```bash
   npm install
   npm run dev
   ```
5. **Test edge functions:**
   - Use Lovable's built-in preview
   - Check edge function logs for errors

### 11.2 How GPT Should Be Prompted Using This Document

**Prompt Template:**

```
I am continuing development on Resumate, an ATS-friendly resume generator.

PROJECT CONTEXT:
- Tech stack: React 18, TypeScript, Vite, Tailwind CSS, Supabase Edge Functions
- Backend: Deno runtime, Lovable AI Gateway (google/gemini-2.5-flash)
- No database tables, client-side state only
- Privacy-first: no persistent storage of resume data

CURRENT ARCHITECTURE:
[Paste relevant section from documentation]

MY TASK:
[Describe what you want to build]

CONSTRAINTS:
- Must maintain ATS-safe output (single column, standard fonts)
- AI can enhance but not fabricate content
- Error handling required for rate limits (429) and credit exhaustion (402)
- Follow existing component patterns in src/components/generator/

Please provide implementation with:
1. TypeScript types if new data structures needed
2. Edge function code if backend logic required
3. React component following existing patterns
4. Error handling and loading states
```

### 11.3 What Context Must Always Be Preserved

**Critical Context:**

1. **Resume Data Model:** Always reference `src/types/resume.ts` for structure
2. **Edge Function Pattern:** CORS headers, error codes, JSON response format
3. **AI Prompt Format:** Return ONLY JSON, no markdown, specific instructions
4. **ATS Requirements:** Single column, standard fonts, no graphics
5. **Privacy First:** No persistent storage, client-side state only
6. **Score Calculation:** 100-point scale with defined categories
7. **Template System:** 5 templates with consistent style configs

**Files to Reference:**
- `src/types/resume.ts` - Data model
- `src/components/generator/ImproveResumeFlow.tsx` - Main flow orchestration
- `src/components/generator/ResumeTemplates.tsx` - Template definitions
- `supabase/functions/*/index.ts` - Backend patterns

---

## Appendix A: Complete File List

```
.env
.gitignore
README.md
DOCUMENTATION.md (this file)
bun.lockb
components.json
eslint.config.js
index.html
package-lock.json
package.json
postcss.config.js
public/
  favicon.ico
  favicon.jpg
  favicon.png
  placeholder.svg
  robots.txt
src/
  App.css
  App.tsx
  assets/
    resumate-new-logo.png
  components/
    NavLink.tsx
    generator/
      ATSAnalysisCard.tsx
      EnhancedResumeEditor.tsx
      ImproveResumeFlow.tsx
      ModeSelector.tsx
      ResumeForm.tsx
      ResumePreview.tsx
      ResumeTemplates.tsx
      ResumeUploader.tsx
      ScoreComparison.tsx
      TemplateSelector.tsx
    ui/
      (40+ Shadcn components)
  data/
    indianLocations.ts
  hooks/
    use-mobile.tsx
    use-toast.ts
  index.css
  integrations/
    supabase/
      client.ts
      types.ts
  lib/
    utils.ts
  main.tsx
  pages/
    Generator.tsx
    Index.tsx
    NotFound.tsx
  types/
    resume.ts
  vite-env.d.ts
supabase/
  config.toml
  functions/
    analyze-resume/
      index.ts
    enhance-content/
      index.ts
    generate-pdf/
      index.ts
    parse-resume/
      index.ts
  migrations/
tailwind.config.ts
tsconfig.app.json
tsconfig.json
tsconfig.node.json
vite.config.ts
```

---

## Appendix B: Edge Function Locations

| Function | Path | Purpose |
|----------|------|---------|
| parse-resume | `supabase/functions/parse-resume/index.ts` | Extract structured data from uploaded files |
| analyze-resume | `supabase/functions/analyze-resume/index.ts` | Calculate ATS score and generate suggestions |
| enhance-content | `supabase/functions/enhance-content/index.ts` | AI-powered text improvement |
| generate-pdf | `supabase/functions/generate-pdf/index.ts` | Generate ATS-formatted text content |

---

## Appendix C: Key Dependencies

```json
{
  "react": "^18.3.1",
  "react-dom": "^18.3.1",
  "react-router-dom": "^6.30.1",
  "@tanstack/react-query": "^5.83.0",
  "@supabase/supabase-js": "^2.89.0",
  "lucide-react": "^0.462.0",
  "tailwindcss": "via config",
  "class-variance-authority": "^0.7.1",
  "clsx": "^2.1.1",
  "tailwind-merge": "^2.6.0"
}
```

---

**Document End**

*This document should be pasted into any AI assistant before continuing development. It provides complete context for understanding and extending the Resumate project.*
