import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ParsedResume {
  contact: {
    name: string;
    email: string;
    phone: string;
    location: string;
    linkedin?: string;
    github?: string;
    portfolio?: string;
  };
  summary: string;
  experience: Array<{
    role: string;
    company: string;
    startDate: string;
    endDate: string;
    bullets: string[];
  }>;
  education: Array<{
    degree: string;
    institution: string;
    graduationDate: string;
    gpa?: string;
  }>;
  skills: string[];
  projects: Array<{
    name: string;
    description: string;
    technologies: string[];
    link?: string;
  }>;
  certifications: Array<{
    name: string;
    issuer: string;
    date: string;
    credentialId?: string;
  }>;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { fileContent, fileName, fileBase64, mimeType } = await req.json();
    
    if (!fileContent && !fileBase64) {
      return new Response(
        JSON.stringify({ error: 'No file content provided' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Parsing resume: ${fileName}`);
    
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const systemPrompt = `You are a resume parser that extracts structured data from resumes. 
You MUST respond with ONLY a valid JSON object, no other text, no markdown code blocks.
Extract ONLY what is explicitly written in the resume. Do NOT invent or hallucinate any information.
If a field is not present, use empty string "" for strings or empty array [] for arrays.`;

    const jsonStructure = `{
  "contact": {
    "name": "Full Name",
    "email": "email@example.com",
    "phone": "phone number",
    "location": "City, State",
    "linkedin": "linkedin url if present or empty string",
    "github": "github url if present or empty string",
    "portfolio": "portfolio/website url if present or empty string"
  },
  "summary": "Professional summary if present, otherwise empty string",
  "experience": [
    {
      "role": "Job Title",
      "company": "Company Name",
      "startDate": "Month Year",
      "endDate": "Month Year or Present",
      "bullets": ["Achievement 1", "Achievement 2"]
    }
  ],
  "education": [
    {
      "degree": "Degree Name",
      "institution": "School Name",
      "graduationDate": "Month Year or empty string",
      "gpa": "GPA if listed or empty string"
    }
  ],
  "skills": ["Skill 1", "Skill 2"],
  "projects": [
    {
      "name": "Project Name",
      "description": "Brief description of the project",
      "technologies": ["Tech 1", "Tech 2"],
      "link": "project url if present or empty string"
    }
  ],
  "certifications": [
    {
      "name": "Certification Name",
      "issuer": "Issuing Organization",
      "date": "Month Year",
      "credentialId": "Credential ID if present or empty string"
    }
  ]
}`;

    let messages: any[];
    
    // Check if we have base64 content (for PDF/DOCX files)
    if (fileBase64 && mimeType) {
      console.log(`Processing file with mimeType: ${mimeType}`);
      
      // Use vision capability for PDF files
      messages = [
        { role: 'system', content: systemPrompt },
        { 
          role: 'user', 
          content: [
            {
              type: 'text',
              text: `Parse this resume document and return a JSON object with this exact structure:\n${jsonStructure}\n\nRespond with ONLY the JSON object, no explanation.`
            },
            {
              type: 'image_url',
              image_url: {
                url: `data:${mimeType};base64,${fileBase64}`
              }
            }
          ]
        }
      ];
    } else {
      // Plain text content
      const isPdfBinary = fileContent.startsWith('%PDF');
      
      if (isPdfBinary) {
        console.log('Detected PDF binary content sent as text - this should not happen');
        return new Response(
          JSON.stringify({ 
            error: 'PDF processing error. Please try again.' 
          }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Clean up the content
      const cleanedContent = fileContent
        .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F]/g, '')
        .trim();

      if (!cleanedContent || cleanedContent.length < 50) {
        console.log('Content too short or empty after cleaning');
        return new Response(
          JSON.stringify({ error: 'Could not extract readable text from the file. Please try a different file.' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      console.log(`Content length: ${cleanedContent.length} characters`);

      messages = [
        { role: 'system', content: systemPrompt },
        { 
          role: 'user', 
          content: `Parse this resume and return a JSON object with this exact structure:\n${jsonStructure}\n\nResume content to parse:\n---\n${cleanedContent.substring(0, 15000)}\n---\n\nRespond with ONLY the JSON object, no explanation.`
        }
      ];
    }

    console.log('Sending request to AI gateway...');

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages,
        temperature: 0.1,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI Gateway error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded. Please try again in a moment.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'AI credits exhausted. Please add more credits.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const aiResponse = await response.json();
    console.log('AI response received');
    
    const content = aiResponse.choices?.[0]?.message?.content;

    if (!content) {
      console.error('No content in AI response:', JSON.stringify(aiResponse));
      throw new Error('No response from AI');
    }

    console.log('AI response content length:', content.length);

    // Extract JSON from the response
    let parsedResume: ParsedResume;
    try {
      let jsonContent = content.trim();
      
      // Remove markdown code blocks
      if (jsonContent.startsWith('```json')) {
        jsonContent = jsonContent.slice(7);
      } else if (jsonContent.startsWith('```')) {
        jsonContent = jsonContent.slice(3);
      }
      if (jsonContent.endsWith('```')) {
        jsonContent = jsonContent.slice(0, -3);
      }
      jsonContent = jsonContent.trim();

      // Try to find JSON object in the response
      const jsonMatch = jsonContent.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        parsedResume = JSON.parse(jsonMatch[0]);
        console.log('Successfully parsed JSON from response');
      } else {
        console.error('No JSON object found in response:', content.substring(0, 500));
        throw new Error('No JSON found in response');
      }
    } catch (parseError) {
      console.error('Failed to parse AI response:', parseError);
      console.error('Raw content:', content.substring(0, 1000));
      throw new Error('Failed to parse resume structure');
    }

    // Validate and fix the structure
    parsedResume = {
      contact: {
        name: parsedResume.contact?.name || '',
        email: parsedResume.contact?.email || '',
        phone: parsedResume.contact?.phone || '',
        location: parsedResume.contact?.location || '',
        linkedin: parsedResume.contact?.linkedin || '',
        github: parsedResume.contact?.github || '',
        portfolio: parsedResume.contact?.portfolio || '',
      },
      summary: parsedResume.summary || '',
      experience: Array.isArray(parsedResume.experience) ? parsedResume.experience : [],
      education: Array.isArray(parsedResume.education) ? parsedResume.education : [],
      skills: Array.isArray(parsedResume.skills) ? parsedResume.skills : [],
      projects: Array.isArray(parsedResume.projects) ? parsedResume.projects : [],
      certifications: Array.isArray(parsedResume.certifications) ? parsedResume.certifications : [],
    };

    // Ensure experience is chronologically ordered (most recent first)
    if (parsedResume.experience.length > 0) {
      parsedResume.experience.sort((a, b) => {
        const dateA = new Date(a.startDate || '');
        const dateB = new Date(b.startDate || '');
        if (isNaN(dateA.getTime()) || isNaN(dateB.getTime())) return 0;
        return dateB.getTime() - dateA.getTime();
      });
    }

    console.log('Successfully parsed resume');

    return new Response(
      JSON.stringify(parsedResume),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in parse-resume function:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error occurred' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
