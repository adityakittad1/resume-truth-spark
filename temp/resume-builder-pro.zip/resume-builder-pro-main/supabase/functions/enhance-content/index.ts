import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { content, type } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    if (!content || content.trim() === '') {
      return new Response(
        JSON.stringify({ error: "Content is required" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let systemPrompt = '';
    
    switch (type) {
      case 'summary':
        systemPrompt = `You are an expert resume writer who helps craft compelling professional summaries. 
Your task is to enhance the given professional summary to be:
- More impactful and engaging while maintaining a natural, humanized tone
- ATS-friendly with relevant keywords
- Concise (2-3 sentences max)
- Written in first person without using "I"
- Professional but not robotic or overly formal

Return ONLY the enhanced summary text, nothing else. Do not add quotes or explanations.`;
        break;
        
      case 'bullet':
        systemPrompt = `You are an expert resume writer who creates powerful achievement bullets.
Your task is to enhance the given job responsibility/achievement to be:
- Action-oriented, starting with a strong action verb
- Quantified with metrics where possible (add realistic placeholders like [X%] if none provided)
- More impactful while maintaining a natural, humanized tone
- ATS-friendly with relevant keywords
- Concise (1 sentence, under 20 words ideally)

Return ONLY the enhanced bullet point text, nothing else. Do not add quotes, bullet symbols, or explanations.`;
        break;
        
      default:
        systemPrompt = `You are an expert resume writer. Enhance the given content to be more professional, impactful, and ATS-friendly while maintaining a natural, humanized tone. Return ONLY the enhanced text, nothing else.`;
    }

    console.log(`Enhancing ${type} content:`, content.substring(0, 100));

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `Please enhance this ${type}: "${content}"` }
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI usage limit reached. Please try again later." }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    const enhancedContent = data.choices?.[0]?.message?.content?.trim();

    if (!enhancedContent) {
      throw new Error("No content returned from AI");
    }

    console.log("Enhanced content:", enhancedContent.substring(0, 100));

    return new Response(
      JSON.stringify({ enhanced: enhancedContent }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error("Error in enhance-content function:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error occurred" }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
