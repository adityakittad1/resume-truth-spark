import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ResumeData {
  contact: {
    name: string;
    email: string;
    phone: string;
    location: string;
    linkedin?: string;
  };
  summary: string;
  experience: Array<{
    role: string;
    company: string;
    startDate: string;
    endDate: string;
    bullets: string[];
  }>;
  education: Array<{
    degree: string;
    institution: string;
    graduationDate: string;
    gpa?: string;
  }>;
  skills: string[];
}

// Generate ATS-friendly plain text resume
function generateATSText(data: ResumeData): string {
  const lines: string[] = [];
  
  // Header - Name prominently
  lines.push(data.contact.name.toUpperCase());
  lines.push('');
  
  // Contact info on one line
  const contactParts = [data.contact.email, data.contact.phone, data.contact.location];
  if (data.contact.linkedin) {
    contactParts.push(data.contact.linkedin);
  }
  lines.push(contactParts.filter(Boolean).join(' | '));
  lines.push('');
  
  // Summary
  if (data.summary && data.summary.trim()) {
    lines.push('PROFESSIONAL SUMMARY');
    lines.push('-'.repeat(50));
    lines.push(data.summary);
    lines.push('');
  }
  
  // Experience
  if (data.experience && data.experience.length > 0) {
    lines.push('PROFESSIONAL EXPERIENCE');
    lines.push('-'.repeat(50));
    
    for (const exp of data.experience) {
      lines.push(`${exp.role}`);
      lines.push(`${exp.company} | ${exp.startDate} - ${exp.endDate}`);
      for (const bullet of exp.bullets) {
        lines.push(`• ${bullet}`);
      }
      lines.push('');
    }
  }
  
  // Education
  if (data.education && data.education.length > 0) {
    lines.push('EDUCATION');
    lines.push('-'.repeat(50));
    
    for (const edu of data.education) {
      lines.push(`${edu.degree}`);
      let eduLine = edu.institution;
      if (edu.graduationDate) {
        eduLine += ` | ${edu.graduationDate}`;
      }
      if (edu.gpa) {
        eduLine += ` | GPA: ${edu.gpa}`;
      }
      lines.push(eduLine);
      lines.push('');
    }
  }
  
  // Skills
  if (data.skills && data.skills.length > 0) {
    lines.push('SKILLS');
    lines.push('-'.repeat(50));
    lines.push(data.skills.join(' | '));
  }
  
  return lines.join('\n');
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { resumeData } = await req.json();
    
    if (!resumeData) {
      return new Response(
        JSON.stringify({ error: 'No resume data provided' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Generating ATS-friendly resume for:', resumeData.contact?.name);

    // Generate plain text content
    const textContent = generateATSText(resumeData);

    // Return as text/plain which can be easily converted to PDF on client
    // or used directly for ATS systems
    return new Response(
      JSON.stringify({ 
        textContent,
        resumeData
      }),
      { 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json'
        } 
      }
    );

  } catch (error) {
    console.error('Error in generate-pdf function:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error occurred' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
