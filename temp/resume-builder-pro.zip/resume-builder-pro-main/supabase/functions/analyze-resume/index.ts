import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ATSAnalysis {
  score: number;
  issues: {
    category: string;
    severity: 'high' | 'medium' | 'low';
    message: string;
    section?: string;
  }[];
  suggestions: {
    section: string;
    current: string;
    suggested: string;
    reason: string;
  }[];
  strengths: string[];
  keywords: {
    found: string[];
    missing: string[];
  };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { resumeData } = await req.json();
    
    if (!resumeData) {
      return new Response(
        JSON.stringify({ error: 'Resume data is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    console.log('Analyzing resume for ATS compatibility...');

    const systemPrompt = `You are an expert ATS (Applicant Tracking System) analyzer. Analyze resumes for ATS compatibility and provide detailed feedback.

You MUST respond with ONLY a valid JSON object, no markdown, no code blocks, no explanations.`;

    const userPrompt = `Analyze this resume for ATS compatibility and provide a detailed analysis.

Resume Data:
${JSON.stringify(resumeData, null, 2)}

Return a JSON object with this exact structure:
{
  "score": <number 0-100 representing overall ATS compatibility>,
  "issues": [
    {
      "category": "<formatting|content|keywords|structure>",
      "severity": "<high|medium|low>",
      "message": "<specific issue description>",
      "section": "<contact|summary|experience|education|skills or null>"
    }
  ],
  "suggestions": [
    {
      "section": "<summary|experience|skills>",
      "current": "<current problematic text or 'Missing'>",
      "suggested": "<improved version>",
      "reason": "<why this improvement helps ATS>"
    }
  ],
  "strengths": ["<positive aspect 1>", "<positive aspect 2>"],
  "keywords": {
    "found": ["<keyword found in resume>"],
    "missing": ["<important keyword that should be added>"]
  }
}

Scoring criteria:
- Contact info completeness: 10 points
- Professional summary quality: 15 points
- Experience with quantified achievements: 30 points
- Action verbs usage: 10 points
- Skills section relevance: 15 points
- Education completeness: 10 points
- Overall formatting/structure: 10 points

Be specific and actionable in your feedback. Focus on:
1. Missing quantifiable metrics in bullet points
2. Weak or passive language
3. Missing important keywords for the apparent field
4. Formatting issues that ATS systems struggle with
5. Content gaps that make the resume less competitive`;

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI Gateway error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded. Please try again in a moment.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'AI credits exhausted. Please add more credits.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const aiResponse = await response.json();
    const content = aiResponse.choices?.[0]?.message?.content;

    if (!content) {
      throw new Error('No response from AI');
    }

    console.log('AI analysis response received');

    // Parse JSON from response
    let analysis: ATSAnalysis;
    try {
      let jsonContent = content.trim();
      
      // Remove markdown code blocks if present
      if (jsonContent.startsWith('```json')) {
        jsonContent = jsonContent.slice(7);
      } else if (jsonContent.startsWith('```')) {
        jsonContent = jsonContent.slice(3);
      }
      if (jsonContent.endsWith('```')) {
        jsonContent = jsonContent.slice(0, -3);
      }
      jsonContent = jsonContent.trim();

      const jsonMatch = jsonContent.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        analysis = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('No JSON found in response');
      }
    } catch (parseError) {
      console.error('Failed to parse AI response:', parseError);
      console.error('Raw content:', content.substring(0, 1000));
      throw new Error('Failed to parse analysis');
    }

    // Validate and ensure structure
    analysis = {
      score: Math.min(100, Math.max(0, analysis.score || 0)),
      issues: Array.isArray(analysis.issues) ? analysis.issues : [],
      suggestions: Array.isArray(analysis.suggestions) ? analysis.suggestions : [],
      strengths: Array.isArray(analysis.strengths) ? analysis.strengths : [],
      keywords: {
        found: Array.isArray(analysis.keywords?.found) ? analysis.keywords.found : [],
        missing: Array.isArray(analysis.keywords?.missing) ? analysis.keywords.missing : []
      }
    };

    console.log('Successfully analyzed resume, score:', analysis.score);

    return new Response(
      JSON.stringify(analysis),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in analyze-resume function:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error occurred' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
