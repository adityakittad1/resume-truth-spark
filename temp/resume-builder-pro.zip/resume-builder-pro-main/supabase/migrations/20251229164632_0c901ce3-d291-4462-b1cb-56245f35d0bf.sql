-- Create storage bucket for resume uploads
INSERT INTO storage.buckets (id, name, public)
VALUES ('resume-uploads', 'resume-uploads', false);

-- Allow authenticated users to upload files
CREATE POLICY "Users can upload resume files"
ON storage.objects
FOR INSERT
WITH CHECK (bucket_id = 'resume-uploads');

-- Allow users to read their own uploads
CREATE POLICY "Users can read resume files"
ON storage.objects
FOR SELECT
USING (bucket_id = 'resume-uploads');

-- Allow users to delete their uploads
CREATE POLICY "Users can delete resume files"
ON storage.objects
FOR DELETE
USING (bucket_id = 'resume-uploads');