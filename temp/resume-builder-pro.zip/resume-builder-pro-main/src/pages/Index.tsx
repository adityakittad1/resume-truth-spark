import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { FileText, Linkedin } from "lucide-react";
import resumateLogo from "@/assets/resumate-new-logo.png";

const Index = () => {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <main className="flex flex-1 items-center justify-center">
        <div className="text-center">
          <img 
            src={resumateLogo} 
            alt="Resumate - ATS Resume Generator" 
            className="h-24 mx-auto mb-6 rounded-lg shadow-lg animate-bounce-in hover-lift"
          />
          <h1 className="mb-4 text-4xl font-bold animate-fade-in-up delay-200" style={{ opacity: 0 }}>
            Resumate
          </h1>
          <p className="text-xl text-muted-foreground mb-8 animate-fade-in-up delay-300" style={{ opacity: 0 }}>
            Create an ATS-friendly resume that gets past automated screening systems.
          </p>
          <Link to="/generator">
            <Button size="lg" className="btn-animated animate-fade-in-up delay-400" style={{ opacity: 0 }}>
              <FileText className="w-5 h-5 mr-2" />
              Create Your Resume
            </Button>
          </Link>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t bg-muted/30">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground">
              © 2025 Resumate. Built by Aditya Kittad.
            </p>
            <a 
              href="https://www.linkedin.com/company/resumate-io/" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              <Button 
                variant="outline" 
                size="sm" 
                className="gap-2 transition-all duration-300 hover:scale-105 hover:bg-[#0077B5]/10 hover:border-[#0077B5]/50 hover:text-[#0077B5]"
              >
                <Linkedin className="w-4 h-4" />
                Connect on LinkedIn
              </Button>
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
