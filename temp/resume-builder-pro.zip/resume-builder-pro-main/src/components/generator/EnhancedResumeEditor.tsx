import { useState } from "react";
import { 
  Sparkles, 
  Loader2, 
  Edit3, 
  Check, 
  X, 
  Plus, 
  Trash2,
  ChevronDown,
  ChevronUp,
  Briefcase,
  GraduationCap,
  User,
  Wrench,
  FolderKanban,
  Award
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ResumeData, ResumeExperience, ResumeEducation, ResumeProject, ResumeCertification } from "@/types/resume";

interface EnhancedResumeEditorProps {
  data: ResumeData;
  onChange: (data: ResumeData) => void;
}

export function EnhancedResumeEditor({ data, onChange }: EnhancedResumeEditorProps) {
  const [enhancingField, setEnhancingField] = useState<string | null>(null);
  const [editingField, setEditingField] = useState<string | null>(null);
  const [tempValue, setTempValue] = useState<string>("");
  const [sectionsOpen, setSectionsOpen] = useState({
    summary: true,
    experience: true,
    education: true,
    skills: true,
    projects: true,
    certifications: true
  });
  const [skillInput, setSkillInput] = useState("");
  const [techInput, setTechInput] = useState<{ [key: string]: string }>({});
  const { toast } = useToast();

  const enhanceContent = async (content: string, type: 'summary' | 'bullet', fieldId: string) => {
    if (!content.trim()) {
      toast({
        title: "Nothing to enhance",
        description: "Please enter some text first.",
        variant: "destructive",
      });
      return null;
    }

    setEnhancingField(fieldId);
    
    try {
      const { data: responseData, error } = await supabase.functions.invoke('enhance-content', {
        body: { content, type }
      });

      if (error) throw error;
      if (responseData.error) throw new Error(responseData.error);

      toast({
        title: "Enhanced!",
        description: "Content improved with AI.",
      });

      return responseData.enhanced;
    } catch (error) {
      console.error('Enhancement error:', error);
      toast({
        title: "Enhancement failed",
        description: error instanceof Error ? error.message : "Please try again.",
        variant: "destructive",
      });
      return null;
    } finally {
      setEnhancingField(null);
    }
  };

  const startEditing = (fieldId: string, value: string) => {
    setEditingField(fieldId);
    setTempValue(value);
  };

  const cancelEditing = () => {
    setEditingField(null);
    setTempValue("");
  };

  const saveEdit = (updateFn: (value: string) => void) => {
    updateFn(tempValue);
    setEditingField(null);
    setTempValue("");
  };

  // Summary handlers
  const handleEnhanceSummary = async () => {
    const enhanced = await enhanceContent(data.summary, 'summary', 'summary');
    if (enhanced) {
      onChange({ ...data, summary: enhanced });
    }
  };

  // Experience handlers
  const updateExperience = (id: string, field: keyof Omit<ResumeExperience, 'id'>, value: any) => {
    onChange({
      ...data,
      experience: data.experience.map(exp =>
        exp.id === id ? { ...exp, [field]: value } : exp
      )
    });
  };

  const updateBullet = (expId: string, bulletIdx: number, value: string) => {
    onChange({
      ...data,
      experience: data.experience.map(exp =>
        exp.id === expId
          ? { ...exp, bullets: exp.bullets.map((b, i) => i === bulletIdx ? value : b) }
          : exp
      )
    });
  };

  const addBullet = (expId: string) => {
    onChange({
      ...data,
      experience: data.experience.map(exp =>
        exp.id === expId ? { ...exp, bullets: [...exp.bullets, ''] } : exp
      )
    });
  };

  const removeBullet = (expId: string, bulletIdx: number) => {
    onChange({
      ...data,
      experience: data.experience.map(exp =>
        exp.id === expId
          ? { ...exp, bullets: exp.bullets.filter((_, i) => i !== bulletIdx) }
          : exp
      )
    });
  };

  const handleEnhanceBullet = async (expId: string, bulletIdx: number) => {
    const exp = data.experience.find(e => e.id === expId);
    if (!exp) return;
    
    const bullet = exp.bullets[bulletIdx];
    const enhanced = await enhanceContent(bullet, 'bullet', `${expId}-${bulletIdx}`);
    if (enhanced) {
      updateBullet(expId, bulletIdx, enhanced);
    }
  };

  const addExperience = () => {
    const newExp: ResumeExperience = {
      id: `exp-${Date.now()}`,
      role: '',
      company: '',
      startDate: '',
      endDate: '',
      bullets: ['']
    };
    onChange({ ...data, experience: [...data.experience, newExp] });
  };

  const removeExperience = (id: string) => {
    onChange({ ...data, experience: data.experience.filter(exp => exp.id !== id) });
  };

  // Education handlers
  const updateEducation = (id: string, field: keyof Omit<ResumeEducation, 'id'>, value: string) => {
    onChange({
      ...data,
      education: data.education.map(edu =>
        edu.id === id ? { ...edu, [field]: value } : edu
      )
    });
  };

  const addEducation = () => {
    const newEdu: ResumeEducation = {
      id: `edu-${Date.now()}`,
      degree: '',
      institution: '',
      graduationDate: '',
      gpa: ''
    };
    onChange({ ...data, education: [...data.education, newEdu] });
  };

  const removeEducation = (id: string) => {
    onChange({ ...data, education: data.education.filter(edu => edu.id !== id) });
  };

  // Skills handlers
  const addSkill = () => {
    const skill = skillInput.trim();
    if (skill && !data.skills.includes(skill)) {
      onChange({ ...data, skills: [...data.skills, skill] });
      setSkillInput("");
    }
  };

  const removeSkill = (skillToRemove: string) => {
    onChange({ ...data, skills: data.skills.filter(skill => skill !== skillToRemove) });
  };

  // Project handlers
  const updateProject = (id: string, field: keyof Omit<ResumeProject, 'id'>, value: any) => {
    onChange({
      ...data,
      projects: data.projects.map(proj =>
        proj.id === id ? { ...proj, [field]: value } : proj
      )
    });
  };

  const addProject = () => {
    const newProj: ResumeProject = {
      id: `proj-${Date.now()}`,
      name: '',
      description: '',
      technologies: [],
      link: ''
    };
    onChange({ ...data, projects: [...data.projects, newProj] });
  };

  const removeProject = (id: string) => {
    onChange({ ...data, projects: data.projects.filter(proj => proj.id !== id) });
  };

  const addTechnology = (projId: string) => {
    const tech = techInput[projId]?.trim();
    if (tech) {
      onChange({
        ...data,
        projects: data.projects.map(proj =>
          proj.id === projId && !proj.technologies.includes(tech)
            ? { ...proj, technologies: [...proj.technologies, tech] }
            : proj
        )
      });
      setTechInput(prev => ({ ...prev, [projId]: '' }));
    }
  };

  const removeTechnology = (projId: string, tech: string) => {
    onChange({
      ...data,
      projects: data.projects.map(proj =>
        proj.id === projId
          ? { ...proj, technologies: proj.technologies.filter(t => t !== tech) }
          : proj
      )
    });
  };

  // Certification handlers
  const updateCertification = (id: string, field: keyof Omit<ResumeCertification, 'id'>, value: string) => {
    onChange({
      ...data,
      certifications: data.certifications.map(cert =>
        cert.id === id ? { ...cert, [field]: value } : cert
      )
    });
  };

  const addCertification = () => {
    const newCert: ResumeCertification = {
      id: `cert-${Date.now()}`,
      name: '',
      issuer: '',
      date: '',
      credentialId: ''
    };
    onChange({ ...data, certifications: [...data.certifications, newCert] });
  };

  const removeCertification = (id: string) => {
    onChange({ ...data, certifications: data.certifications.filter(cert => cert.id !== id) });
  };

  const toggleSection = (section: keyof typeof sectionsOpen) => {
    setSectionsOpen(prev => ({ ...prev, [section]: !prev[section] }));
  };

  return (
    <div className="space-y-4">
      {/* Summary Section */}
      <Card className="border-0 shadow-lg">
        <Collapsible open={sectionsOpen.summary} onOpenChange={() => toggleSection('summary')}>
          <CollapsibleTrigger asChild>
            <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-3">
              <CardTitle className="flex items-center justify-between text-lg">
                <span className="flex items-center gap-2">
                  <User className="w-4 h-4 text-primary" />
                  Professional Summary
                </span>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 gap-1 text-xs"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleEnhanceSummary();
                    }}
                    disabled={enhancingField === 'summary' || !data.summary.trim()}
                  >
                    {enhancingField === 'summary' ? (
                      <Loader2 className="w-3 h-3 animate-spin" />
                    ) : (
                      <Sparkles className="w-3 h-3" />
                    )}
                    Enhance
                  </Button>
                  {sectionsOpen.summary ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              </CardTitle>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="pt-0">
              <Textarea
                value={data.summary}
                onChange={(e) => onChange({ ...data, summary: e.target.value })}
                placeholder="Write a compelling professional summary..."
                className="min-h-[100px] resize-none"
              />
            </CardContent>
          </CollapsibleContent>
        </Collapsible>
      </Card>

      {/* Experience Section */}
      <Card className="border-0 shadow-lg">
        <Collapsible open={sectionsOpen.experience} onOpenChange={() => toggleSection('experience')}>
          <CollapsibleTrigger asChild>
            <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-3">
              <CardTitle className="flex items-center justify-between text-lg">
                <span className="flex items-center gap-2">
                  <Briefcase className="w-4 h-4 text-primary" />
                  Experience ({data.experience.length})
                </span>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 gap-1 text-xs"
                    onClick={(e) => {
                      e.stopPropagation();
                      addExperience();
                    }}
                  >
                    <Plus className="w-3 h-3" />
                    Add
                  </Button>
                  {sectionsOpen.experience ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              </CardTitle>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="pt-0 space-y-4">
              {data.experience.map((exp, expIdx) => (
                <div key={exp.id} className="p-4 rounded-lg bg-muted/30 border border-border/50 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 grid grid-cols-2 gap-3">
                      <Input
                        value={exp.role}
                        onChange={(e) => updateExperience(exp.id, 'role', e.target.value)}
                        placeholder="Job Title"
                        className="font-semibold"
                      />
                      <Input
                        value={exp.company}
                        onChange={(e) => updateExperience(exp.id, 'company', e.target.value)}
                        placeholder="Company Name"
                      />
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="ml-2 text-destructive hover:text-destructive"
                      onClick={() => removeExperience(exp.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      value={exp.startDate}
                      onChange={(e) => updateExperience(exp.id, 'startDate', e.target.value)}
                      placeholder="Start Date (e.g., Jan 2022)"
                    />
                    <Input
                      value={exp.endDate}
                      onChange={(e) => updateExperience(exp.id, 'endDate', e.target.value)}
                      placeholder="End Date (or Present)"
                    />
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Achievements & Responsibilities</p>
                    {exp.bullets.map((bullet, bulletIdx) => (
                      <div key={bulletIdx} className="flex items-start gap-2">
                        <span className="mt-2.5 w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                        <Input
                          value={bullet}
                          onChange={(e) => updateBullet(exp.id, bulletIdx, e.target.value)}
                          placeholder="Describe an achievement or responsibility..."
                          className="flex-1"
                        />
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-9 w-9 p-0"
                          onClick={() => handleEnhanceBullet(exp.id, bulletIdx)}
                          disabled={enhancingField === `${exp.id}-${bulletIdx}` || !bullet.trim()}
                        >
                          {enhancingField === `${exp.id}-${bulletIdx}` ? (
                            <Loader2 className="w-3 h-3 animate-spin" />
                          ) : (
                            <Sparkles className="w-3 h-3" />
                          )}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-9 w-9 p-0 text-destructive hover:text-destructive"
                          onClick={() => removeBullet(exp.id, bulletIdx)}
                          disabled={exp.bullets.length <= 1}
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                    <Button
                      size="sm"
                      variant="outline"
                      className="w-full mt-2 gap-1"
                      onClick={() => addBullet(exp.id)}
                    >
                      <Plus className="w-3 h-3" />
                      Add Bullet Point
                    </Button>
                  </div>
                </div>
              ))}
              
              {data.experience.length === 0 && (
                <div className="text-center py-6 text-muted-foreground">
                  <Briefcase className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p>No experience added yet</p>
                  <Button
                    size="sm"
                    variant="outline"
                    className="mt-2 gap-1"
                    onClick={addExperience}
                  >
                    <Plus className="w-3 h-3" />
                    Add Experience
                  </Button>
                </div>
              )}
            </CardContent>
          </CollapsibleContent>
        </Collapsible>
      </Card>

      {/* Education Section */}
      <Card className="border-0 shadow-lg">
        <Collapsible open={sectionsOpen.education} onOpenChange={() => toggleSection('education')}>
          <CollapsibleTrigger asChild>
            <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-3">
              <CardTitle className="flex items-center justify-between text-lg">
                <span className="flex items-center gap-2">
                  <GraduationCap className="w-4 h-4 text-primary" />
                  Education ({data.education.length})
                </span>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 gap-1 text-xs"
                    onClick={(e) => {
                      e.stopPropagation();
                      addEducation();
                    }}
                  >
                    <Plus className="w-3 h-3" />
                    Add
                  </Button>
                  {sectionsOpen.education ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              </CardTitle>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="pt-0 space-y-4">
              {data.education.map((edu) => (
                <div key={edu.id} className="p-4 rounded-lg bg-muted/30 border border-border/50 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 grid grid-cols-2 gap-3">
                      <Input
                        value={edu.degree}
                        onChange={(e) => updateEducation(edu.id, 'degree', e.target.value)}
                        placeholder="Degree / Certification"
                        className="font-semibold"
                      />
                      <Input
                        value={edu.institution}
                        onChange={(e) => updateEducation(edu.id, 'institution', e.target.value)}
                        placeholder="Institution Name"
                      />
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="ml-2 text-destructive hover:text-destructive"
                      onClick={() => removeEducation(edu.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      value={edu.graduationDate}
                      onChange={(e) => updateEducation(edu.id, 'graduationDate', e.target.value)}
                      placeholder="Graduation Date"
                    />
                    <Input
                      value={edu.gpa || ''}
                      onChange={(e) => updateEducation(edu.id, 'gpa', e.target.value)}
                      placeholder="GPA (optional)"
                    />
                  </div>
                </div>
              ))}
              
              {data.education.length === 0 && (
                <div className="text-center py-6 text-muted-foreground">
                  <GraduationCap className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p>No education added yet</p>
                  <Button
                    size="sm"
                    variant="outline"
                    className="mt-2 gap-1"
                    onClick={addEducation}
                  >
                    <Plus className="w-3 h-3" />
                    Add Education
                  </Button>
                </div>
              )}
            </CardContent>
          </CollapsibleContent>
        </Collapsible>
      </Card>

      {/* Skills Section */}
      <Card className="border-0 shadow-lg">
        <Collapsible open={sectionsOpen.skills} onOpenChange={() => toggleSection('skills')}>
          <CollapsibleTrigger asChild>
            <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-3">
              <CardTitle className="flex items-center justify-between text-lg">
                <span className="flex items-center gap-2">
                  <Wrench className="w-4 h-4 text-primary" />
                  Skills ({data.skills.length})
                </span>
                {sectionsOpen.skills ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </CardTitle>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="pt-0 space-y-3">
              <div className="flex gap-2">
                <Input
                  value={skillInput}
                  onChange={(e) => setSkillInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && addSkill()}
                  placeholder="Add a skill and press Enter..."
                  className="flex-1"
                />
                <Button onClick={addSkill} disabled={!skillInput.trim()}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {data.skills.map((skill, idx) => (
                  <Badge 
                    key={idx} 
                    variant="secondary" 
                    className="px-3 py-1.5 text-sm gap-1 cursor-pointer hover:bg-destructive/10 transition-colors group"
                    onClick={() => removeSkill(skill)}
                  >
                    {skill}
                    <X className="w-3 h-3 opacity-50 group-hover:opacity-100" />
                  </Badge>
                ))}
              </div>
              
              {data.skills.length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No skills added yet. Add skills that are relevant to your target role.
                </p>
              )}
            </CardContent>
          </CollapsibleContent>
        </Collapsible>
      </Card>

      {/* Projects Section */}
      <Card className="border-0 shadow-lg">
        <Collapsible open={sectionsOpen.projects} onOpenChange={() => toggleSection('projects')}>
          <CollapsibleTrigger asChild>
            <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-3">
              <CardTitle className="flex items-center justify-between text-lg">
                <span className="flex items-center gap-2">
                  <FolderKanban className="w-4 h-4 text-primary" />
                  Projects ({data.projects?.length || 0})
                </span>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 gap-1 text-xs"
                    onClick={(e) => {
                      e.stopPropagation();
                      addProject();
                    }}
                  >
                    <Plus className="w-3 h-3" />
                    Add
                  </Button>
                  {sectionsOpen.projects ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              </CardTitle>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="pt-0 space-y-4">
              {data.projects?.map((proj) => (
                <div key={proj.id} className="p-4 rounded-lg bg-muted/30 border border-border/50 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 grid grid-cols-2 gap-3">
                      <Input
                        value={proj.name}
                        onChange={(e) => updateProject(proj.id, 'name', e.target.value)}
                        placeholder="Project Name"
                        className="font-semibold"
                      />
                      <Input
                        value={proj.link || ''}
                        onChange={(e) => updateProject(proj.id, 'link', e.target.value)}
                        placeholder="Project URL (optional)"
                      />
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="ml-2 text-destructive hover:text-destructive"
                      onClick={() => removeProject(proj.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <Textarea
                    value={proj.description}
                    onChange={(e) => updateProject(proj.id, 'description', e.target.value)}
                    placeholder="Brief description of the project..."
                    className="min-h-[60px] resize-none"
                  />

                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Technologies</p>
                    <div className="flex gap-2">
                      <Input
                        value={techInput[proj.id] || ''}
                        onChange={(e) => setTechInput(prev => ({ ...prev, [proj.id]: e.target.value }))}
                        onKeyDown={(e) => e.key === 'Enter' && addTechnology(proj.id)}
                        placeholder="Add technology..."
                        className="flex-1"
                      />
                      <Button 
                        size="sm"
                        onClick={() => addTechnology(proj.id)} 
                        disabled={!techInput[proj.id]?.trim()}
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {proj.technologies.map((tech, idx) => (
                        <Badge 
                          key={idx} 
                          variant="outline" 
                          className="px-2 py-1 text-xs gap-1 cursor-pointer hover:bg-destructive/10 transition-colors group"
                          onClick={() => removeTechnology(proj.id, tech)}
                        >
                          {tech}
                          <X className="w-3 h-3 opacity-50 group-hover:opacity-100" />
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
              
              {(!data.projects || data.projects.length === 0) && (
                <div className="text-center py-6 text-muted-foreground">
                  <FolderKanban className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p>No projects added yet</p>
                  <Button
                    size="sm"
                    variant="outline"
                    className="mt-2 gap-1"
                    onClick={addProject}
                  >
                    <Plus className="w-3 h-3" />
                    Add Project
                  </Button>
                </div>
              )}
            </CardContent>
          </CollapsibleContent>
        </Collapsible>
      </Card>

      {/* Certifications Section */}
      <Card className="border-0 shadow-lg">
        <Collapsible open={sectionsOpen.certifications} onOpenChange={() => toggleSection('certifications')}>
          <CollapsibleTrigger asChild>
            <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-3">
              <CardTitle className="flex items-center justify-between text-lg">
                <span className="flex items-center gap-2">
                  <Award className="w-4 h-4 text-primary" />
                  Certifications ({data.certifications?.length || 0})
                </span>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 gap-1 text-xs"
                    onClick={(e) => {
                      e.stopPropagation();
                      addCertification();
                    }}
                  >
                    <Plus className="w-3 h-3" />
                    Add
                  </Button>
                  {sectionsOpen.certifications ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              </CardTitle>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="pt-0 space-y-4">
              {data.certifications?.map((cert) => (
                <div key={cert.id} className="p-4 rounded-lg bg-muted/30 border border-border/50 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 grid grid-cols-2 gap-3">
                      <Input
                        value={cert.name}
                        onChange={(e) => updateCertification(cert.id, 'name', e.target.value)}
                        placeholder="Certification Name"
                        className="font-semibold"
                      />
                      <Input
                        value={cert.issuer}
                        onChange={(e) => updateCertification(cert.id, 'issuer', e.target.value)}
                        placeholder="Issuing Organization"
                      />
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="ml-2 text-destructive hover:text-destructive"
                      onClick={() => removeCertification(cert.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      value={cert.date}
                      onChange={(e) => updateCertification(cert.id, 'date', e.target.value)}
                      placeholder="Issue Date"
                    />
                    <Input
                      value={cert.credentialId || ''}
                      onChange={(e) => updateCertification(cert.id, 'credentialId', e.target.value)}
                      placeholder="Credential ID (optional)"
                    />
                  </div>
                </div>
              ))}
              
              {(!data.certifications || data.certifications.length === 0) && (
                <div className="text-center py-6 text-muted-foreground">
                  <Award className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p>No certifications added yet</p>
                  <Button
                    size="sm"
                    variant="outline"
                    className="mt-2 gap-1"
                    onClick={addCertification}
                  >
                    <Plus className="w-3 h-3" />
                    Add Certification
                  </Button>
                </div>
              )}
            </CardContent>
          </CollapsibleContent>
        </Collapsible>
      </Card>
    </div>
  );
}
